
/**
 * Write a description of class Time1 here.
 *
 * @author Jacob Yanov)
 * @version (a version number or a date)
 */
public class Time1{

    ///Feilds
    private int _hour;
    private int _minute;

    /**Constructor*/
    public Time1(int hour,int minute){
        _hour=hour;
        _minute=minute;
        setMinute(_minute);
        setHour(_hour);
    }
    /**Constructor*/
    public Time1(Time1 t){

        _hour=new Integer(t.getHour());
        _minute=new Integer(t.getMinute());
    }

    /**Getters*/
    public int getMinute(){
        return _minute;
    }

    public int getHour(){
        return _hour;
    }

    /**Setters*/
    public void setMinute(int num){
        if(num>=60 || num < 0){
            num=0;
        }
        _minute=num;
    }

    public void setHour(int num){
        if(num>=24 || num < 0){
            num=0; 
        }
        _hour=num;
    }

    /**toString*/
    public String toString(){//8
        int minuteMax=59;
        int minuteMin=0;
        int hourMax=24;
        int hourMin=0;
        String time="";
        if(_hour<=hourMin || _hour>=hourMax){//invalid hour format
            time+="00:";
            if(_minute<=minuteMin || _minute>=minuteMax){
                time+="00";
            }else if(_minute<=9){
                time+="0"+_minute;
            }else{
                time+=_minute;
            }

        }else if(_hour<=9){//hour less equal then 9
            time+="0"+_hour+":";
            if(_minute<=minuteMin || _minute>=minuteMax){
                time+="00";
            }else if(_minute<=9){
                time+="0"+_minute;
            }else{
                time+=_minute;
            }

        }else if(_minute<=minuteMin || _minute>=minuteMax){//invalid minute format
            time+=_hour+":00";

        }else if(_minute<=9){//minute less equal then 9
            time+=_hour+":0"+_minute;

        }else{//valid time
            time+=_hour+":"+_minute;
        }
        return time;
    }

    /**minFromMidnight*/
    public int minFromMidnight(){//returns minutes
        int hourMinutes= _hour * 60;//get minutes from hour
        int total=hourMinutes + _minute;//add
        return total;
    }

    /**equals*/
    public boolean equals(Time1 other){//Time equals
        if(other.getHour()==_hour && other.getMinute()==_minute){
            return true;
        }
        return false;
    }

    /**before*/
    public boolean before(Time1 time){//Time before
        if(time.getHour()>_hour && time.getMinute()>_minute){
            return true;
        }else if(time.getHour()==_hour && time.getMinute()>_minute){
            return true;
        }else if(time.getHour()==_hour && time.getMinute()==_minute){
            System.out.println("The time is equal");
            return false;
        }
        return false;
    }

    /**after*/
    public boolean after(Time1 time){//Time after

        return time.before(this);
    }

    /**difference*/
    public int difference(Time1 time){
        int hourDiffrence= _hour- time.getHour();//get hour diffrence
        int minuteDiffrence= _minute- time.getMinute();//get minute diffrence
        hourDiffrence*=60;//get minutes from hour
        int total=hourDiffrence+minuteDiffrence;//add
        return total;
    }

    /**addMinutes*/
    public Time1 addMinutes(int num){//12 30
        Time1 copy = new Time1(this);//copy time

        int leftOverMod = num%60;//get left minutes //30
        float leftOverDiv = Math.round(num/60);//get hours from minutes
        int value = (int)leftOverDiv;//convert to int//1

        int minutes=copy.getMinute();//30
        int hours=copy.getHour()+value;//add to hours the minutes
        //checks for adding minutes and subtracting them

        //check for 24 format
        if(hours>24 || hours<0){
            int hourMod=hours%24;  
            if(hourMod>0){
                copy.setHour(hourMod);
            }else{
                copy.setHour(-hourMod);
            }  
        }

        if(num>0){
            if(minutes+leftOverMod>60){
                System.out.println(hours);
                hours+=1;
                int newMinutes=minutes+leftOverMod-60;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else if(minutes+leftOverMod==60){
                hours+=1;
                int newMinutes=0;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else{
                int newMinutes=minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }

        }else if(num<0){

            if(minutes+leftOverMod<0){
                int newMinutes=60+minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else if(minutes+leftOverMod==60){
                hours+=1;
                int newMinutes=0;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else{
                int newMinutes=minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }

        }

        return copy;
    }

}

