
/**
 * Write a description of class RailwayStation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RailwayStation
{
    /**
     * fields
     * 
     * 
     * 
     * 
     */
    private Train [] _station;
    private int _noOfTrs;
    private final int MAX_TRAINS=100;

    /**
     * default constructor
     * 
     * 
     * 
     * 
     */

    public RailwayStation(){
        _station=new Train[MAX_TRAINS];
        _noOfTrs=0;

    }

    /**
     * add train
     * 
     * 
     * 
     * 
     */
    public boolean addTrain(Train f){
        Train ifExist=null;
        for(int i=0;i<_noOfTrs;i++){
            if(f.equals(_station[i])){
                ifExist=_station[i];
            }
        }

        if(_station[0]==null){
            _station[0]=new Train(f);
            _noOfTrs++;
            return true;

        }else if(_noOfTrs == _station.length) {

            return false;//no room in array

        }else if (ifExist!=null){

            return false;

        }else{
            _station [_noOfTrs] = new Train (f);//avoid aliasing
            _noOfTrs++;
            return true;
        }
    }

    /**
     * remove train
     * 
     * 
     * 
     * 
     */
    public boolean removeTrain(Train f){
        Train ifExist=null;
        for(int i=0;i<_noOfTrs;i++){
            if(f.equals(_station[i])){
                ifExist=_station[i];
            }
        }
        if(_station[0]==null || ifExist==null){
            System.out.println("Please add at least one train");
            return false;
        }else{
            Train lastTrain =_station[_noOfTrs-1];

            for (int i =0;i<_noOfTrs;i++){
                if(f.equals(_station[i])){
                    _station[i]=lastTrain;

                }
            }

            _noOfTrs--;
        }

        return true;
    }

    /**
     * Return a  first time of all the trains
     * 
     * 
     * 
     * 
     * 
     */
    public Time1 firstDepartureToDestination (String place){

        /**
        get number of same destination and initilize array
         */
        int string=0;
        for(int i=0;i<_noOfTrs;i++){
            if(_station[i].getDestination().equalsIgnoreCase(place)){
                string++; 
            }
        }
        Train[] trainsTo = new Train[string];

        /**
        put all the item with same destination to an array
         */
        for(int i=0;i<trainsTo.length;i++){
            for(int j=0;j<_noOfTrs;j++){
                if(_station[j].getDestination().equalsIgnoreCase(place)){
                    trainsTo[i]=_station[j];

                }
            }
        }

        /**
        if there is no trains to destination retunr  null
         */
        if(string==0){
            return null;

            /**
            if there is more then one train to destination get one that arrives first
             */    
        }else if(string>0) {
            Train beforeTrain=trainsTo[0];
            Time1 time =null;
            for (int i=1;i<trainsTo.length;i++){
                if(beforeTrain.arrivesEarlier(trainsTo[i])){
                    time=beforeTrain.getDeparture();
                    beforeTrain=beforeTrain;
                }else{
                    time=trainsTo[i].getDeparture();
                    beforeTrain=trainsTo[i];
                }
            }
            return time;

            /**
            if there exact one train then added
             */   
        }else{
            Train beforeTrain=trainsTo[0];

            return beforeTrain.getDeparture();
        }
    }

    
    /**
     * Return a string of all the flights
     * 
     * 
     * 
     * 
     * 
     */
    public String mostPopularDestination(){

        /**
        get the most popular destinations
         */
        String mostPopular="";
        for(int i=0;i<_noOfTrs;i++){
            for(int j=1;j<_noOfTrs;j++){
                if(_station[i].getDestination().equalsIgnoreCase(_station[j].getDestination())){
                    mostPopular+=_station[i].getDestination()+",";
                }
            }

        }

        /**
        get the most popular destination
         */
        String[] words = mostPopular.split(",");
        int finalCount = 0;
        int tempCount = 0;
        String mostlyUsedWord = null;
        for (String word: words) {
            tempCount = 0;
            for (String w: words) {
                if (word.equalsIgnoreCase(w)) {
                    tempCount++;
                }
            }
            if (tempCount >= finalCount) {
                finalCount = tempCount;
                mostlyUsedWord = word;
            }
        }

        return mostlyUsedWord;
    }

    /**
     * Return mostExpensiveTicket
     * 
     * 
     * 
     * 
     * 
     */
    public Train mostExpensiveTicket(){
        Train mostExpensiveTrain=null;
        int max=0;
        int min =0;
        for(int i=1;i<_noOfTrs;i++){
            min=_station[0].getPrice();
            max=_station[i].getPrice();
            if(min>max){
                mostExpensiveTrain=_station[0];
            }else{
                mostExpensiveTrain=_station[i];
            }

        }
        return mostExpensiveTrain;
    }

    /**
     * Return longestTrain
     * 
     * 
     * 
     * 
     * 
     */
    public Train longestTrain(){
        Train mostLongest=null;
        int max=0;
        int min=0;
        for(int i=1;i<_noOfTrs;i++){
            min=_station[0].getDuration();
            max=_station[i].getDuration();
            if(min>max){
                mostLongest=_station[0];
            }else{
                mostLongest=_station[i];
            }

        }
        return mostLongest;
    }

    /**
     * Return a string of all the flights
     * 
     */
    public String toString(){
        String s=" :The trains today are:\n";
        for (int i = 0; i < _noOfTrs; i++) {
            s+=_station[i].toString()+"\n";
        }
        return s;
    }

    /**
     * Return number of full trains
     * 
     */
    public int howManyFullTrains(){
        int fullTrains=0;
        for (int i = 0; i < _noOfTrs; i++) {
            if(_station[i].isFull()){
                fullTrains++;
            }
        }
        return fullTrains;
    }
}
