
/**
 * Write a description of class f here.
 *
 * @author (Jacob Yanov)
 * @version (a version number or a date)
 */
public class Time2{

    /**Field*/
    private int _minFromMid;

    /**Constructor*/
    public Time2(int h,int m){
        if(h>=24 || h<0){
            h=0;
        }
        if(m>=60 || m<0){
            m=0;
        }
        _minFromMid=h*60+m;
    }

    /**Constructor*/
    public Time2(Time2 other){
        _minFromMid=new Integer(other.getHour()*60+other.getMinute());
    }

    /**Getters*/
    public int getMinute(){
        int minutes= _minFromMid%60;
        return minutes;
    }

    public int getHour(){
        float getHour = Math.round(_minFromMid/60);
        int value = (int)getHour;
        return value;
    }

    /**Setters*/ 
    public void setMinute(int num){
        if(num>=60 || num < 0){
            num=0;
        }
        if(num>getMinute()){
            int value = num - getMinute();
            _minFromMid+=value;
        }else if(num<getMinute()){
            int value = getMinute()-num;
            _minFromMid-=value;
        }
    }

    public void setHour(int num){
        if(num>=24 || num < 0){
            num=0; 
        }

        if(num>getHour()){
            int value = (num - getHour())*60;

            _minFromMid+=value;
        }else if(num<getHour()){
            int value = (getHour()-num)*60;

            _minFromMid-=value;
        }
    }

    /**toString*/
    public String toString(){
        int minuteMax=59;
        int minuteMin=0;
        int hourMax=24;
        int hourMin=0;
        String time="";
        if(getHour()<=hourMin || getHour()>=hourMax){//invalid hour format
            time+="00:";
            if(getMinute()<=minuteMin || getMinute()>=minuteMax){
                time+="00";
            }else if(getMinute()<=9){
                time+="0"+getMinute();
            }else{
                time+=getMinute();
            }
        }else if(getHour()<=9){//hour less equal then 
            time+="0"+getHour()+":";
            if(getMinute()<=minuteMin || getMinute()>=minuteMax){
                time+="00";
            }else if(getMinute()<=9){
                time+="0"+getMinute();
            }else{
                time+=getMinute();
            }
        }else if(getMinute()<=minuteMin || getMinute()>=minuteMax){//invalid minute format
            time+=getHour()+":00";
        }else if(getMinute()<=9){//minute less equal then 
            time+=getHour()+":0"+getMinute();
        }else{//valid time
            time+=getHour()+":"+getMinute();
        }
        return time;
    }

    /**minFromMidnight*/
    public int minFromMidnight(){
        return _minFromMid;
    }

    /**equals*/
    public boolean equals(Time2 other){//Time equals
        if(other.getHour()==getHour() && other.getMinute()==getMinute()){
            return true;
        }
        return false;
    }

    /**before*/
    public boolean before(Time2 time){//Time before
        if(time.getHour()>getHour() && time.getMinute()>getMinute()){
            return true;
        }else if(time.getHour()==getHour() && time.getMinute()>getMinute()){
            return true;
        }else if(time.getHour()==getHour() && time.getMinute()==getMinute()){
            System.out.println("The time is equal");
            return false;
        }
        return false;
    }

    /**after*/
    public boolean after(Time2 time){//Time after
        return time.before(this);
    }

    /**difference*/
    public int difference(Time2 time){
        int hourDiffrence= getHour()- time.getHour();//get hour diffrence
        int minuteDiffrence= getMinute()- time.getMinute();//get minute diffrence
        hourDiffrence*=60;//get minutes from hour
        int total=hourDiffrence+minuteDiffrence;//add
        return total;
    }

    /**addMinutes*/
    public Time2 addMinutes(int num){
        Time2 copy = new Time2(this);
        int leftOverMod = num%60;
        float leftOverDiv = Math.round(num/60);
        int value = (int)leftOverDiv;
        int minutes=copy.getMinute();
        int hours=copy.getHour()+value;
        if(num>0){
            if(minutes+leftOverMod>60){
                hours+=1;
                int newMinutes=minutes+leftOverMod-60;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else{
                int newMinutes=minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }
        }else if(num<0){
            if(minutes+leftOverMod<0){
                int newMinutes=60+minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }else{
                int newMinutes=minutes+leftOverMod;
                copy.setMinute(newMinutes);
                copy.setHour(hours);
            }
        }
        //check for 24 format
        if(hours>24 || hours<0){
            int hourMod=hours%24;  
            if(hourMod>0){
                copy.setHour(hourMod);
            }else{
                copy.setHour(-hourMod);
            }  
        }

        return copy;
    }

}