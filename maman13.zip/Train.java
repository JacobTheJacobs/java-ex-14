
/**
 * Write a description of class Train here.
 *
 * @author (Jacob Yanov)
 * @version (a version number or a date)
 */
public class Train
{  
    private String _destination;
    private Time1 _departure;
    private int _duration;
    private int _passengers;
    private int _seats;
    private int _price;

    /**Constructor*/
    public Train(String destination, int hour, int minute,int duration,int passengers, int seats,int price){
        _destination=destination;
        if(minute<0){
            minute=0;  
        }

        Time1 departure = new Time1(hour,minute);
        Time1 copy = new Time1(departure);
        copy.setHour(hour);
        copy.setMinute(minute);
        _departure=copy;

        _duration=duration;
        if(passengers>seats){
            _passengers=0;
        }else if(passengers<0){
            _passengers=0; 
        }else{
            _passengers=passengers;
            _seats=seats;
        }

        if(price<0){
            _price=0;
        }else{
            _price=price;
        }
    }

    /**Constructor*/
    public Train(Train train){
        _destination=new String(train._destination);
        _departure = new Time1(train._departure);
        _duration=new Integer(train._duration);
        _passengers=new Integer(train._passengers);
        _seats=new Integer(train._seats);
        _price=new Integer(train._price);

    }

    /**Getters*/
    public String getDestination(){
        return _destination; 
    }

    public Time1 getDeparture(){
        return _departure; 
    }

    public int getDuration(){
        return _duration; 
    }

    public int getPassengers(){
        return _passengers; 
    }

    public int getSeats(){
        return _seats; 
    }

    public int getPrice(){
        return _price; 
    }

    /**Setters*/
    public void setDestination(String destination){
        _destination=destination;
    }

    public void setDeparture(Time1 departure){
        _departure=departure;
    }

    public void setDuration(int duration){
        _duration=duration;
    }

    public void setPassengers(int passengers){
        _passengers=passengers;
    }

    public void setSeats(int seats){
        _seats=seats;
    }

    /**setPrice*/
    public void setPrice(int price){
        _price=price;
    }

    /**equal*/
    public boolean equals(Train train){
         if(train.getDestination().equals(_destination) && train.getSeats()==_seats && train.getDeparture().equals(_departure)){
            return true;
        }
        return false;
    }

    /**getArrivalTime*/
    public Time1 getArrivalTime(){
        return _departure.addMinutes(_duration);

    }

    /**addPassengers*/
    public boolean addPassengers(int num){
        if(_passengers+num>_seats){

            return false;
        }
        _passengers+=num;
        return true;
    }

    /**isFull*/
    public boolean isFull(){
        if(_passengers>=_seats){
            return true;
        }
        return false;
    }

    /**isCheaper*/
    public boolean isCheaper(Train train){
        if(train.getPrice()>_price){
            return true; 
        }
        return false;
    }

    /**totalPrice*/
    public int totalPrice(){
        int total=_price*_passengers;
        return total;
    }

    /**arrivesEarlier*/
    public boolean arrivesEarlier(Train train){
        Time1 time1=getArrivalTime();
        Time1 time2=train.getArrivalTime();
        if(time1.before(time2)){
            return true;
        }
        return false;
    }

    /**toString*/
    public String toString(){
        String result="Train to "+ _destination+" departs at "+ _departure+"." ;
        if(isFull()){
            result+="Train is full";
        }else{
            result+="Train is not full"; 
        }
        return result;
    }

}
